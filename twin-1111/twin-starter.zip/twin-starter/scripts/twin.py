#!/usr/bin/env python3
"""Digital-twin pipeline over the ElevenLabs + HeyGen APIs (stdlib only, no installs).
Based on Mor Nissim's own mechanism. (c) Mor Nissim / Flow M.N. Ltd.

Keys live in ~/.config/twin/keys.env (the user pastes them; never print them).
Chosen IDs are saved to ~/.config/twin/ids.env by `check`.
The HeyGen key is optional: without it, use `voice` and upload the mp3 to HeyGen by hand.

  python3 -I avatar_api.py check                    # verify keys, list her cloned voices + digital-twin looks, save ids
  python3 -I avatar_api.py voice  <script.txt> <out.mp3>
  python3 -I avatar_api.py sts    <my_recording.m4a> <out.mp3>   # her own reading re-voiced (keeps her energy)
  python3 -I avatar_api.py video  <voice.mp3> <out.mp4>   # upload audio, render 9:16 1080p avatar video, download
  python3 -I avatar_api.py make   <script.txt> <outDir>   # voice + video -> outDir/voice.mp3, outDir/avatar.mp4

`video` and `make` spend HeyGen/ElevenLabs credits — run them only after the user approved the script.
"""
import json, os, sys, time, uuid, urllib.request, urllib.error


BANNER = """
==============================================================
  התאומה הדיגיטלית · המנגנון נבנה על ידי מור נסים (Flow)
  © כל הזכויות שמורות למור נסים ולחברת פלואו מ.נ. בע"מ
  לשימוש אישי בלבד, אסור להעביר הלאה
==============================================================
"""

CFG = os.path.expanduser('~/.config/twin')
os.makedirs(CFG, exist_ok=True)
EL = 'https://api.elevenlabs.io'
HG = 'https://api.heygen.com'


def load_env(name):
    env = {}
    p = os.path.join(CFG, name)
    if os.path.exists(p):
        for line in open(p, encoding='utf-8'):
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return env


KEYS, IDS = load_env('keys.env'), load_env('ids.env')


def req(method, url, headers=None, body=None, raw=False, timeout=300):
    r = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            data = resp.read()
    except urllib.error.HTTPError as e:
        msg = e.read().decode('utf-8', 'replace')[:600]
        sys.exit(f'HTTP {e.code} from {url.split("?")[0]}: {msg}')
    return data if raw else json.loads(data or b'{}')


def el_h(extra=None):
    k = KEYS.get('ELEVENLABS_API_KEY')
    if not k: sys.exit('ELEVENLABS_API_KEY missing in ~/.config/twin/keys.env')
    return {'xi-api-key': k, **(extra or {})}


def hg_h(extra=None):
    k = KEYS.get('HEYGEN_API_KEY')
    if not k: sys.exit('HEYGEN_API_KEY missing in ~/.config/twin/keys.env')
    return {'X-Api-Key': k, 'Accept': 'application/json', **(extra or {})}


def save_ids(d):
    cur = load_env('ids.env'); cur.update({k: v for k, v in d.items() if v})
    with open(os.path.join(CFG, 'ids.env'), 'w', encoding='utf-8') as f:
        f.write('# chosen automatically by avatar_api.py check — edit to switch voice/look\n')
        for k, v in cur.items(): f.write(f'{k}={v}\n')
    os.chmod(os.path.join(CFG, 'ids.env'), 0o600)


def check():
    print(BANNER)
    voices = req('GET', f'{EL}/v1/voices', el_h()).get('voices', [])
    cloned = [v for v in voices if v.get('category') in ('cloned', 'professional', 'generated')]
    print('ElevenLabs — your voices:')
    for v in cloned: print(f"  {v['voice_id']}  {v.get('name')}  ({v.get('category')})")
    items = []
    if KEYS.get('HEYGEN_API_KEY'):
        looks = req('GET', f'{HG}/v3/avatars/looks?avatar_type=digital_twin&ownership=private', hg_h())
        items = looks.get('data', {})
        items = items.get('looks', items.get('items', items)) if isinstance(items, dict) else items
        print('HeyGen — your digital-twin looks:')
        for l in items or []: print(f"  {l.get('id')}  {l.get('name')}")
    else:
        print('HeyGen key not set — semi-automatic mode: make the voice here, upload the mp3 to HeyGen by hand.')
    pick = {}
    if len(cloned) == 1: pick['ELEVEN_VOICE_ID'] = cloned[0]['voice_id']
    if items and len(items) == 1: pick['HEYGEN_AVATAR_ID'] = items[0].get('id')
    pick.setdefault('ELEVEN_MODEL', IDS.get('ELEVEN_MODEL', 'eleven_v4'))
    save_ids(pick)
    print('saved:', {k: v for k, v in load_env('ids.env').items()})
    ids = load_env('ids.env')
    if 'ELEVEN_VOICE_ID' not in ids or (KEYS.get('HEYGEN_API_KEY') and 'HEYGEN_AVATAR_ID' not in ids):
        print('More than one option (or none) — ask the user which one, then write it to ~/.config/twin/ids.env')


def voice(script_path, out):
    vid = IDS.get('ELEVEN_VOICE_ID') or sys.exit('run check first (ELEVEN_VOICE_ID)')
    text = open(script_path, encoding='utf-8').read().strip()
    body = json.dumps({'text': text, 'model_id': IDS.get('ELEVEN_MODEL', 'eleven_v4'),
                       'voice_settings': {'stability': float(os.environ.get('ELEVEN_STABILITY', IDS.get('ELEVEN_STABILITY', 0.5))),
                                          'similarity_boost': float(IDS.get('ELEVEN_SIMILARITY', 0.8))}}).encode()
    audio = req('POST', f'{EL}/v1/text-to-speech/{vid}?output_format=mp3_44100_128',
                el_h({'Content-Type': 'application/json', 'Accept': 'audio/mpeg'}), body, raw=True)
    open(out, 'wb').write(audio); print('voice saved', out, len(audio), 'bytes')


def sts(recording, out):
    """Speech to Speech: the user's own reading (her timing and energy) re-voiced with her clone."""
    vid = IDS.get('ELEVEN_VOICE_ID') or sys.exit('run check first (ELEVEN_VOICE_ID)')
    b = uuid.uuid4().hex
    fields = {'model_id': IDS.get('ELEVEN_STS_MODEL', 'eleven_multilingual_sts_v2'),
              'remove_background_noise': 'true'}
    parts = b''.join(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k, v in fields.items())
    parts += (f'--{b}\r\nContent-Disposition: form-data; name="audio"; filename="{os.path.basename(recording)}"\r\n'
              f'Content-Type: application/octet-stream\r\n\r\n').encode() + open(recording, 'rb').read() + f'\r\n--{b}--\r\n'.encode()
    audio = req('POST', f'{EL}/v1/speech-to-speech/{vid}?output_format=mp3_44100_128',
                el_h({'Content-Type': f'multipart/form-data; boundary={b}', 'Accept': 'audio/mpeg'}), parts, raw=True)
    open(out, 'wb').write(audio); print('sts voice saved', out, len(audio), 'bytes')


def video(mp3, out):
    aid = os.environ.get('HEYGEN_AVATAR_ID') or IDS.get('HEYGEN_AVATAR_ID') or sys.exit('run check first (HEYGEN_AVATAR_ID), or pass HEYGEN_AVATAR_ID=<look id>')
    b = uuid.uuid4().hex
    payload = (f'--{b}\r\nContent-Disposition: form-data; name="file"; filename="voice.mp3"\r\n'
               f'Content-Type: audio/mpeg\r\n\r\n').encode() + open(mp3, 'rb').read() + f'\r\n--{b}--\r\n'.encode()
    up = req('POST', f'{HG}/v3/assets', hg_h({'Content-Type': f'multipart/form-data; boundary={b}'}), payload)
    asset = (up.get('data') or {}).get('id') or (up.get('data') or {}).get('asset_id') or sys.exit(f'upload failed: {up}')
    body = {'type': 'avatar', 'avatar_id': aid, 'audio_asset_id': asset, 'aspect_ratio': '9:16',
            'resolution': '1080p', 'title': os.path.basename(os.path.dirname(os.path.abspath(out)))}
    if IDS.get('HEYGEN_ENGINE'): body['engine'] = {'type': IDS['HEYGEN_ENGINE']}
    cr = req('POST', f'{HG}/v3/videos', hg_h({'Content-Type': 'application/json'}), json.dumps(body).encode())
    vid = (cr.get('data') or {}).get('video_id') or sys.exit(f'create failed: {cr}')
    print('heygen video', vid, '— rendering…', flush=True)
    for _ in range(240):  # up to ~40 min
        time.sleep(10)
        st = req('GET', f'{HG}/v3/videos/{vid}', hg_h()).get('data') or {}
        s = st.get('status')
        if s == 'completed':
            data = req('GET', st['video_url'], raw=True, timeout=600)  # clean render (no captions)
            open(out, 'wb').write(data); print('avatar video saved', out, len(data), 'bytes'); return
        if s == 'failed':
            sys.exit(f"heygen failed: {st.get('failure_code')} {st.get('failure_message')}")
    sys.exit(f'timed out waiting for heygen video {vid}')


if __name__ == '__main__':
    cmd, *a = sys.argv[1:] or ['help']
    if cmd == 'check': check()
    elif cmd == 'voice': voice(*a)
    elif cmd == 'sts': sts(*a)
    elif cmd == 'video': video(*a)
    elif cmd == 'make':
        os.makedirs(a[1], exist_ok=True)
        voice(a[0], os.path.join(a[1], 'voice.mp3')); video(os.path.join(a[1], 'voice.mp3'), os.path.join(a[1], 'avatar.mp4'))
    else: print(BANNER); print(__doc__)
